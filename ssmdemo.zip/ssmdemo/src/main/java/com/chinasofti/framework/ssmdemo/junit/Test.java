package com.chinasofti.framework.ssmdemo.junit;

import com.chinasofti.framework.ssmdemo.dao.ProductDAO;
import com.chinasofti.framework.ssmdemo.model.Book;
import com.chinasofti.framework.ssmdemo.web.ProductController;

import java.util.List;

/**
 * Created by Administrator on 2018/7/10/010.
 */
public class Test {

    public static void main(String args[]){
    }
}
