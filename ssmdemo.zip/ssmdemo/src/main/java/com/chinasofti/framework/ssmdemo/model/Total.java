package com.chinasofti.framework.ssmdemo.model;

/**
 * Created by Administrator on 2018/7/11/011.
 */
public class Total {
    private int total;

    public Total(){}

    public int getTotalCount() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }
}
