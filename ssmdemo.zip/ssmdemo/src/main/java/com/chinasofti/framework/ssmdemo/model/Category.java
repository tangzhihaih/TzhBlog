package com.chinasofti.framework.ssmdemo.model;

/**
 * Created by Administrator on 2018/7/10/010.
 */
public class Category {
    private int id;
    private String name;
    public  Category(){}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
